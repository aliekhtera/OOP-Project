package back.usersPackage;

public enum UserType {
    NORMAL_USER,
    BUSINESS_USER
}
