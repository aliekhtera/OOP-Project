package back;

public enum MethodReturns {
    DONE,
    DUPLICATE,
    BAD_INPUT,
    UNKNOWN_DATABASE_ERROR,
    NO_SUCH_OBJECT
}
